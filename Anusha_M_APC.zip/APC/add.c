#include "APC.H"

int add(APC **tail1, APC **tail2, APC **headr, APC **tailr)
{
    int res = 0;      // Variable to hold the sum of digits and carry
    int carry = 0;  // Variable to hold the carry-over

    APC *temp1 = *tail1;  // Pointer to the tail of the first number
    APC *temp2 = *tail2;  // Pointer to the tail of the second number

    // Loop through both numbers until both are exhausted
    while (temp1 != NULL || temp2 != NULL)
    {
        if (temp1 != NULL && temp2 != NULL)
        {
            res = temp1->data + temp2->data + carry;  // Sum digits and carry
            temp1 = temp1->prev;  // Move to the previous digit in the first number
            temp2 = temp2->prev;  // Move to the previous digit in the second number
        }
        else if (temp1 != NULL && temp2 == NULL)
        {
            res = temp1->data + carry;  // Sum digit from the first number with carry
            temp1 = temp1->prev;  // Move to the previous digit in the first number
        }
        else if (temp1 == NULL && temp2 != NULL)
        {
            res = temp2->data + carry;  // Sum digit from the second number with carry
            temp2 = temp2->prev;  // Move to the previous digit in the second number
        }

        // Handle carry if the sum is greater than 9
        if (res > 9)
        {
            res = res % 10;  // Keep only the unit digit
            carry = 1;  // Set carry for the next iteration
        }
        else
        {
            carry = 0;  // No carry needed
        }

        insert_first(headr, tailr, res);  // Insert the result digit at the front of the result list
    }

    // If there’s a remaining carry after the loop, insert it as well
    if (carry == 1)
    {
        insert_first(headr, tailr, carry);  // Insert the final carry
    }

    return SUCCESS;  // Indicate successful addition
}

#include "APC.h"

  int insert_last(APC **headr, APC **tailr, int data)
{
    APC *new = malloc(sizeof(APC));
    if (new == NULL)
        return FAILURE;

    new->data = data;
    new->next = NULL;
    new->prev = NULL;

    // Empty list
    if (*headr == NULL)
    {
        *headr = new;
        *tailr = new;
        return SUCCESS;
    }

    // Non-empty list
    new->prev = *tailr;
    (*tailr)->next = new;
    *tailr = new;

    return SUCCESS;
 

}
#include "APC.H"

int getlen(APC *head)
{
    int count = 0;  // Initialize a counter to zero

    // Traverse the list until the end
    while (head != NULL)
    {
        count++;           // Increment the counter for each node
        head = head->next;  // Move to the next node in the list
    }

    return count;  // Return the total number of nodes
}

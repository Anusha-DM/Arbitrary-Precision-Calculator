#include "APC.h"

int insert_first(APC **headr, APC **tailr, int data)
{
    APC *new=malloc(sizeof(APC));
    if(new==NULL)
    {
        return FAILURE;
    }
    new->data=data;
    new->next=NULL;
    new->prev=NULL;
    if(*headr==NULL)
    {
        *headr=new;
        *tailr=new;
        return SUCCESS;
    }
    else
    {
        (*headr)->prev=new;    
        new->next=(*headr);
        *headr=new;
        return SUCCESS;
    }
    
}
#include "APC.H"

int print_list(APC *headr)
{
    // If the list is empty, print 0
    if (headr == NULL)
    {
        printf("0\n");
        return SUCCESS;
    }

    // Traverse the list and print each digit
    while (headr)
    {
        printf("%d", headr->data);
        headr = headr->next;
    }

    // Move to next line after printing number
    printf("\n");
    return SUCCESS;
}

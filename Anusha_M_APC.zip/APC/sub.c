#include "APC.H"

int sub(APC **tail1, APC **tail2, APC **headr, APC **tailr)
{
    APC *temp1 = *tail1;  // Pointer to the tail of the first number
    APC *temp2 = *tail2;  // Pointer to the tail of the second number
    int res, borrow = 0;  // Variables for result and borrow

    // Loop through each digit from the tail to the head
    while (temp1)
    {
        int d1 = temp1->data - borrow;  // Subtract borrow from the current digit of the first number
        int d2 = temp2 ? temp2->data : 0;  // Get current digit of the second number, or 0 if it’s NULL

        borrow = 0;  // Reset borrow for this iteration
        if (d1 < d2)
        {
            d1 += 10;  // Borrow from the next higher digit
            borrow = 1;  // Set borrow for next iteration
        }

        res = d1 - d2;  // Calculate the result for this digit
        insert_first(headr, tailr, res);  // Insert the result digit at the front of the result list

        temp1 = temp1->prev;  // Move to the previous digit in the first number
        if (temp2)
            temp2 = temp2->prev;  // Move to the previous digit in the second number, if it exists
    }

    // Remove leading zeros from the result
    while (*headr && (*headr)->data == 0 && (*headr)->next)
    {
        APC *tmp = *headr;
        *headr = (*headr)->next;
        (*headr)->prev = NULL;
        free(tmp);  // Free the memory of the leading zero node
    }

    return SUCCESS;  // Indicate successful completion
}

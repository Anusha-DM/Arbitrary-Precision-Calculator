#include "APC.H"

// Global heads and tails for input numbers and result
APC *head1 = NULL, *tail1 = NULL;
APC *head2 = NULL, *tail2 = NULL;
APC *headr = NULL, *tailr = NULL;

int main(int argc, char *argv[])
{
    /* ---------- argument validation ---------- */
    if (argc != 4)
    {
        printf("Usage : ./a.out <num1> <operator> <num2>\n");
        return FAILURE;
    }
    
    if (argv[2][1] != '\0' ||
       (argv[2][0] != '+' && argv[2][0] != '-' &&
        argv[2][0] != 'x' && argv[2][0] != '/'))
    {
        printf("Error : Invalid operator\n");
        return FAILURE;
    }

    int sign1 = 1, sign2 = 1;
    int i, start1 = 0, start2 = 0;
    char temp[2];

    /* ---------- read and store first number ---------- */
    if (argv[1][0] == '-')
        sign1 = -1, start1 = 1;
    else if (argv[1][0] == '+')
        start1 = 1;

    for (i = start1; argv[1][i]; i++)
    {
        temp[0] = argv[1][i];
        temp[1] = '\0';
        insert_last(&head1, &tail1, atoi(temp));
    }

    /* ---------- read and store second number ---------- */
    if (argv[3][0] == '-')
        sign2 = -1, start2 = 1;
    else if (argv[3][0] == '+')
        start2 = 1;

    for (i = start2; argv[3][i]; i++)
    {
        temp[0] = argv[3][i];
        temp[1] = '\0';
        insert_last(&head2, &tail2, atoi(temp));
    }

    int len1 = getlen(head1);
    int len2 = getlen(head2);
    int result_sign = 1;
    char op = argv[2][0];

    /* ---------- ADD / SUB ---------- */
    if (op == '+' || op == '-')
    {
        // Convert subtraction into addition
        if (op == '-')
            sign2 = -sign2;

        if (sign1 == sign2)
        {
            add(&tail1, &tail2, &headr, &tailr);
            result_sign = sign1;
        }
        else
        {
            int cmp = comp(&tail1, &tail2, len1, len2);

            if (cmp == 0)
            {
                printf("0\n");
                return SUCCESS;
            }
            else if (cmp < 0)        // num1 > num2
            {
                sub(&tail1, &tail2, &headr, &tailr);
                result_sign = sign1;
            }
            else                     // num2 > num1
            {
                sub(&tail2, &tail1, &headr, &tailr);
                result_sign = sign2;
            }
        }
    }

    /* ---------- MULTIPLICATION ---------- */
    else if (op == 'x' || op == '*')
    {
        mul(&tail1, &tail2, &headr, &tailr);
        result_sign = sign1 * sign2;
    }

    /* ---------- DIVISION ---------- */
    else if (op == '/')
    {
        if (sign1 * sign2 == -1)
            printf("-");
        divi(&tail1, &tail2, &head1, &head2, &headr, &tailr);
        return SUCCESS;
    }

    // Print sign if result is negative
    if (result_sign == -1)
        printf("-");

    print_list(headr);
    return SUCCESS;
}

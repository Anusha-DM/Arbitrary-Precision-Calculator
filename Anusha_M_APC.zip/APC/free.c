#include "APC.H"

void free_list(APC *head)
{
    APC *temp;  // Temporary pointer to hold the current node

    // Loop through the list and free each node
    while (head)
    {
        temp = head;      // Store the current node in temp
        head = head->next;  // Move to the next node
        free(temp);    // Free the memory of the current node
    }
}

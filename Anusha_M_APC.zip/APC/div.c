#include "APC.H"

// A specialized function to print the division result
void print_division_list(APC *head)
{
    if (head == NULL)
    {
        printf("0\n");
        return;
    }

    // Print each digit in the linked list
    while (head)
    {
        printf("%d", head->data);
        head = head->next;
    }
    printf("\n");
}

int divi(APC **tail1, APC **tail2,
         APC **head1, APC **head2,
         APC **headr, APC **tailr)
{
    int len1 = getlen(*head1);   // Length of the dividend
    int len2 = getlen(*head2);   // Length of the divisor
    int count = 0;               // Counter for the number of subtractions

    // Check for division by zero
    if (*head2 == NULL || (len2 == 1 && (*head2)->data == 0))
    {
        printf("Division by zero\n");
        return FAILURE;
    }

    // Initialize the quotient linked list
    APC *quotient_head = NULL, *quotient_tail = NULL;

    while (1)
    {
        // If the dividend is smaller than the divisor, we stop
        if (len1 < len2)
            break;

        // If the divisor is greater than the dividend (when lengths are equal), we stop
        if (len1 == len2 && comp(tail1, tail2, len1, len2) > 0)
            break;

        // Perform subtraction: dividend = dividend - divisor
        sub(tail1, tail2, headr, tailr);

        // Update the dividend with the result of the subtraction
        free_list(*head1);
        *head1 = *headr;

        // Move the tail pointer to the end of the dividend list
        *tail1 = *head1;
        while ((*tail1)->next)
            *tail1 = (*tail1)->next;

        // Clear the temporary result list for the next iteration
        *headr = NULL;
        *tailr = NULL;

        // Update the length of the dividend
        len1 = getlen(*head1);

        // Increment the quotient counter
        count++;

        // Stop if the dividend becomes zero
        if (len1 == 1 && (*head1)->data == 0)
            break;
    }

    // Now convert the count into a linked list representing the quotient
    if (count == 0)
    {
        // If the count is zero, the quotient is zero
        insert_last(headr, tailr, 0);
    }
    else
    {
        // Convert the count into digits and store in the linked list
        int temp_count = count;
        APC *digit_head = NULL, *digit_tail = NULL;

        // Extract digits from the count and store them in the linked list
        while (temp_count > 0)
        {
            insert_first(&digit_head, &digit_tail, temp_count % 10);
            temp_count /= 10;
        }

        // Link the digits into the quotient list
        *headr = digit_head;
        *tailr = digit_tail;
    }

    // Print the quotient directly inside the divi function using the specialized print function
    print_division_list(*headr);

    return SUCCESS;
}
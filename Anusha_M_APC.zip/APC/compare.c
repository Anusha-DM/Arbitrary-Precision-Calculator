#include "APC.H"

int comp(APC **tail1, APC **tail2, int len1, int len2)
{
    APC *t1 = *tail1;  // Pointer to the tail of the first number
    APC *t2 = *tail2;  // Pointer to the tail of the second number

    if (len1 < len2)
        return 1;   // If first number is shorter, it’s smaller
    if (len1 > len2)
        return -1;  // If first number is longer, it’s greater

    // Compare digits from the most significant to the least significant
    while (t1 && t2)
    {
        if (t1->data < t2->data)
            return 1;   // If first digit is smaller, first number is smaller
        if (t1->data > t2->data)
            return -1;  // If first digit is greater, first number is greater

        t1 = t1->prev;  // Move to the next digit in the first number
        t2 = t2->prev;  // Move to the next digit in the second number
    }

    return 0;  // If all digits are equal, the numbers are equal
}

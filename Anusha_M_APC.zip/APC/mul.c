#include "APC.H"

int mul(APC **tail1, APC **tail2, APC **headr, APC **tailr)
{
    APC *t2 = *tail2;  // Pointer to the tail of the second number
    APC *res_head = NULL, *res_tail = NULL;  // Head and tail for the result list
    int shift = 0;  // Variable to track the positional shift

    // Loop through each digit of the second number
    while (t2)
    {
        APC *t1 = *tail1;  // Pointer to the tail of the first number
        APC *temp_head = NULL, *temp_tail = NULL;  // Head and tail for the intermediate product
        int carry = 0;  // Variable to hold the carry-over

        // Multiply each digit of the first number with the current digit of the second number
        while (t1)
        {
            int mul = t1->data * t2->data + carry;  // Multiply and add carry
            carry = mul / 10;  // Update carry for next digit
            insert_first(&temp_head, &temp_tail, mul % 10);  // Insert the digit into the intermediate product
            t1 = t1->prev;  // Move to the next digit in the first number
        }

        if (carry)
            insert_first(&temp_head, &temp_tail, carry);  // Insert any remaining carry

        // Shift the intermediate product by adding zeros based on the current position
        for (int i = 0; i < shift; i++)
            insert_last(&temp_head, &temp_tail, 0);

        // If this is the first intermediate product, assign it to the result
        if (res_head == NULL)
        {
            res_head = temp_head;
            res_tail = temp_tail;
        }
        else
        {
            // Add the intermediate product to the existing result
            APC *sum_head = NULL, *sum_tail = NULL;
            add(&res_tail, &temp_tail, &sum_head, &sum_tail);  // Sum the intermediate product with the result
            free_list(res_head);  // Free old result memory
            free_list(temp_head);  // Free intermediate product memory
            res_head = sum_head;
            res_tail = sum_tail;
        }

        shift++;  // Increase shift for the next iteration
        t2 = t2->prev;  // Move to the next digit in the second number
    }

    *headr = res_head;  // Assign final result head
    *tailr = res_tail;  // Assign final result tail
    return SUCCESS;  // Indicate successful completion
}
